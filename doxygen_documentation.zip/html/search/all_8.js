var searchData=
[
  ['parent_0',['parent',['../class_tree_nodes_1_1_tree_node_a_b_c.html#a6b957dd910724d564a80aaef9f335303',1,'TreeNodes::TreeNodeABC']]]
];
