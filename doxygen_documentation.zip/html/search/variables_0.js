var searchData=
[
  ['df_0',['df',['../class_data_set_1_1_qual_data_set.html#a2f265300fb4993056ddbe5929e206c9f',1,'DataSet::QualDataSet']]]
];
