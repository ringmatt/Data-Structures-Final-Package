var searchData=
[
  ['ispure_0',['isPure',['../class_tree_nodes_1_1_tree_node_a_b_c.html#afc22f503b2b1aaf68767bd591ffda98c',1,'TreeNodes::TreeNodeABC']]]
];
