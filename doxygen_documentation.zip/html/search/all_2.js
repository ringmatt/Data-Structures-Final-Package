var searchData=
[
  ['classifieralgorithm_0',['ClassifierAlgorithm',['../class_classifier_algorithm_1_1_classifier_algorithm.html',1,'ClassifierAlgorithm']]],
  ['clean_1',['clean',['../class_data_set_1_1_data_set.html#a192d1a59f636f04474030690d5431544',1,'DataSet.DataSet.clean()'],['../class_data_set_1_1_quant_data_set.html#a50a74bfb2c8d0c8deb22344cd0e22889',1,'DataSet.QuantDataSet.clean()'],['../class_data_set_1_1_qual_data_set.html#a689f4ec5f14049691b4c14703437a602',1,'DataSet.QualDataSet.clean()'],['../class_data_set_1_1_text_data_set.html#a39eaf5174f2fc0db0e6ce989709d4fd3',1,'DataSet.TextDataSet.clean()'],['../class_data_set_1_1_time_series_data_set.html#a26f77f416f816c032f075a0da2c1d3c7',1,'DataSet.TimeSeriesDataSet.clean()']]],
  ['confusionmatrix_2',['confusionMatrix',['../class_experiment_1_1_experiment.html#a834e400e4511a14e52d52fa02788f708',1,'Experiment::Experiment']]],
  ['correlation_5fmatrix_3',['correlation_matrix',['../class_data_set_1_1_quant_data_set.html#a8d4a969a956e2a0c496c11c26bfaa898',1,'DataSet::QuantDataSet']]],
  ['crossvalidation_4',['crossValidation',['../class_experiment_1_1_experiment.html#a4be61b01e2a7b722930d749f82354d93',1,'Experiment::Experiment']]]
];
